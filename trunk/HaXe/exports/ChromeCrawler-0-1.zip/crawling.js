// JavaScript Document

var allPages = {};
var crawlStartURL = "";
var startingHost = "";
var maxDepth = parseInt(localStorage["max-crawl-depth"]?localStorage["max-crawl-depth"]:1);
var maxSimultaniousCrawls = parseInt(localStorage["max-page-loads"]?localStorage["max-page-loads"]:5);
var interestingFileTypes = getInterestingFileTypes();

function beginCrawl(url)
{	
	allPages = {};
	appState = "crawling";
	crawlStartURL = url;
	allPages[url] = {url:url, state:"queued", depth:0};
	startingHost = parseUri(url)["protocol"] + "://" + parseUri(url)["host"];
	crawlMore();
}

function crawlPage(page)
{
	allPages[page.url].state = "crawling";
	console.log("Starting Crawl --> "+JSON.stringify(page));
	page.request = $.get(page.url, null,  function(data, textStatus)
	{
		// Dont forget to remove this reference!
		delete page.request;
		
		// If no data than it was aborted handle here
		if(!data) {	page.state = "queued"; }
		else { onCrawlPageLoaded(page,data) ; }
	});
	refreshPage();
}

function onCrawlPageLoaded(page,data)
{	
	// Grab all the links on this page
	var hrefs = getAllAHrefsOnPage(data);	

	console.log("Page Crawled --> "+JSON.stringify(page));
	
	// Loop through each
	$(hrefs).each(function()
	{
		var hrefURL = this+"";	
		var absoluteURL = hrefURL;	
		var parsed = parseUri(hrefURL);
		var protocol = parsed["protocol"];					

		if(startsWith(hrefURL,"/")){ absoluteURL = startingHost+hrefURL; }
		else if(protocol=="javascript"){ console.log("Not Crawling URL, cannot follow javascript --- "+hrefURL); return true; }		
		else if(protocol!="http" && protocol!="https")
		{
			 console.log("Not crawling URL, unknown protocol --- "+hrefURL); return true; 
		}
			
		if(!allPages[absoluteURL])
		{			
			var extn = getFileExt(absoluteURL);
			var o = {url:absoluteURL, state:page.depth==maxDepth?"max_depth":"queued", depth:page.depth+1};
			allPages[absoluteURL] = o;			
			if(isInArr(interestingFileTypes,extn)) { o.isFile=true; }			
		}
		
	});
	
	allPages[page.url].state = "crawled";		
	
	crawlMore();	
	refreshPage();
}

function crawlMore() 
{	
	if(appState!="crawling"){ return; }
	while(getURLsInTab("Crawling").length<maxSimultaniousCrawls && getURLsInTab("Queued").length>0)
	{
		crawlPage(getURLsInTab("Queued")[0]);
	}
}

